package factory;

public enum NotificationType {
    SMS, EMAIL, PUSH
}
