package factory;

public interface Notification {
    void send(String message);
}
