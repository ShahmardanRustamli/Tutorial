package factory;

public class IllegalNotificationTypeException extends RuntimeException {
    public IllegalNotificationTypeException(String message){
        super(message);
    }
}
