package open_close_principle;

public class Car { // bu prinsipde Car`i iki hisseye bolduk ver bir method ile her iki class`imiza da deyisenler teyin etdik.
    public void Petrol(String type){

    }
}
