package file;

public enum FileExplorerType {
    EXCEL, PDF
}
