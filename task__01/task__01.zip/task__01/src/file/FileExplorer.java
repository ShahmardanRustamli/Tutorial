package file;

public interface FileExplorer {
    String fileGenerate (String message);

}
