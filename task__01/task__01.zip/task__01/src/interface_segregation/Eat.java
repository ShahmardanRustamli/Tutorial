package interface_segregation;

public interface Eat {
    void Eat();
}
