package interface_segregation;

public interface Swim {
    void Swim();
}
