package interface_segregation;

public interface Fly {
    void Fly();

}
