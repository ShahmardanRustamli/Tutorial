package Database;

import Model.Book;

public class BookData {
    public static Book[] books;
}
