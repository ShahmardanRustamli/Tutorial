import Database.BookData;
import Service.BookManagement;
import Service.BookService;

public class Main {
    public static void main(String[] args) {
        BookManagement.BookManage();

    }
}
